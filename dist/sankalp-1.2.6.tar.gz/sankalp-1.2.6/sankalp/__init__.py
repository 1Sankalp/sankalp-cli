# sankalp/__init__.py

from .cli import run_cli

__version__ = '0.1.0'

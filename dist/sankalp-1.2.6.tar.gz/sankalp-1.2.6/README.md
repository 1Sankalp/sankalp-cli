# sankalp

A simple interactive CLI for Sankalp Shrivastava.

## After installation, run this to learn more about me!

```python
sankalp
```